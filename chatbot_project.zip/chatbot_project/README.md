# Phoenix Digital Technologies - Website Chatbot

A simple Python chatbot that reads content from the Phoenix Digital
Technologies website (https://phoenixdigitaltech.net/) and answers
user questions about the company, its services, cloud solutions,
AI/ML services, security solutions, and automation services.

## How it works

1. **`scraper.py`** connects to the website using `requests`, parses
   the HTML with `BeautifulSoup`, crawls internal pages (Services,
   Cloud, AI/ML, Security, Automation, etc.), strips out menus/scripts,
   and saves the clean readable text to `website_content.txt`.
2. **`chatbot.py`** loads `website_content.txt`, splits it into
   paragraph-sized chunks, and answers questions by matching keywords
   from the question against keywords in each chunk, returning the
   best-matching chunk(s).
3. You can run the chatbot either as a **console app** or as a
   **Flask web app** with a small chat UI.

## Setup

```bash
pip install -r requirements.txt
```

## Step 1 - Scrape the website (run this first, once)

```bash
python scraper.py
```

This creates `website_content.txt` in the same folder. Re-run this
any time you want to refresh the content from the live site.

## Step 2 - Run the chatbot

### Option A: Console chatbot

```bash
python chatbot.py
```

Example session:
```
You: What services does the company provide?
Bot: <matching text pulled from the website>

You: Does the company provide cloud solutions?
Bot: <matching text pulled from the website>

You: exit
Bot: Goodbye!
```

### Option B: Flask web chatbot

```bash
python app.py
```

Then open **http://127.0.0.1:5000** in your browser. Type a question
or click one of the suggested question buttons.

## Project structure

```
chatbot_project/
├── scraper.py           # Reads & saves website content
├── chatbot.py            # Keyword-matching chatbot + console UI
├── app.py                 # Flask web app
├── templates/
│   └── index.html          # Chat web page
├── requirements.txt
├── website_content.txt   # Created after running scraper.py
└── README.md
```

## How it handles dynamically-phrased questions

Rather than requiring an exact keyword match, `chatbot.py` runs each
question through several layers so differently-worded questions still
find the right answer:

1. **Small talk** - greetings, thanks, goodbye, and "who are you?" get
   direct replies instead of being searched against website content.
2. **Synonym expansion** - abbreviations/related terms (AI ↔
   artificial intelligence, ML ↔ machine learning, sec/cyber ↔
   security, email/phone/call ↔ contact, etc.) are expanded before
   matching, so "cybersecurity" and "security solutions" both hit the
   Security page.
3. **Typo tolerance** - words not found in the site's vocabulary are
   fuzzy-corrected against it (e.g. "teh cloud" -> "the cloud").
4. **TF-IDF + cosine similarity** (via `scikit-learn`) - each
   paragraph of scraped content is scored against the question by
   *meaningful* word/phrase overlap rather than raw string matching,
   so rephrasings like "do you help businesses grow with tech?" still
   land on the right paragraph. Each page's URL (e.g. `/security`) is
   used as a hidden topic hint to sharpen matching further.
5. **Confidence threshold** - if nothing scores well enough, the bot
   says it doesn't have that information and suggests topics it does
   know, instead of returning an unrelated paragraph.

If `scikit-learn` isn't installed, the bot automatically falls back to
plain keyword overlap so it still runs - install it via
`requirements.txt` for the full dynamic matching.

## Notes / possible improvements

- `scraper.py` respects the site by using a normal browser user-agent,
  a request timeout, and a short delay between page requests. If a
  site's `robots.txt` disallows automated access, check with the site
  owner before scraping it in a real/production project.
- For even more dynamic understanding (e.g. handling questions with no
  keyword overlap at all, like "how do you keep my data safe?" mapping
  to "security"), you could swap TF-IDF for sentence embeddings
  (`sentence-transformers`) - the rest of the pipeline (chunking,
  synonym expansion, Flask UI) would stay the same.
