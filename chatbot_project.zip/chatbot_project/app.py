"""
app.py
------
Simple Flask web UI for the website chatbot.

Run:
    python scraper.py   # first, to create website_content.txt
    python app.py        # then start the web server
Then open http://127.0.0.1:5000 in your browser.
"""

from flask import Flask, render_template, request, jsonify

from chatbot import WebsiteChatbot

app = Flask(__name__)

try:
    bot = WebsiteChatbot()
except FileNotFoundError:
    bot = None


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/ask", methods=["POST"])
def ask():
    if bot is None:
        return jsonify({
            "answer": "Website content not found on the server. "
                      "Please run scraper.py first, then restart the app."
        })

    data = request.get_json(silent=True) or {}
    question = data.get("question", "").strip()

    if not question:
        return jsonify({"answer": "Please type a question."})

    answer = bot.answer(question)
    return jsonify({"answer": answer})


if __name__ == "__main__":
    app.run(debug=True)
