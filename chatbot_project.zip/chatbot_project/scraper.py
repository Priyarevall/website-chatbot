"""
scraper.py
----------
Reads the Phoenix Digital Technologies website, extracts readable text
from the homepage and internal pages (e.g. Services, Cloud, AI/ML,
Security, Automation), and stores everything in a local text file
(website_content.txt) so the chatbot can search it offline.

Run this file first, before running chatbot.py or app.py:
    python scraper.py
"""

import time
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

BASE_URL = "https://phoenixdigitaltech.net/"
OUTPUT_FILE = "website_content.txt"
MAX_PAGES = 15          # safety limit so the crawler doesn't wander the whole domain
REQUEST_TIMEOUT = 10    # seconds
DELAY_BETWEEN_REQUESTS = 0.5  # be polite to the server

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0 Safari/537.36"
    )
}


def is_same_domain(url, base_netloc):
    """Only follow links that stay on the same website."""
    return urlparse(url).netloc in ("", base_netloc)


def clean_text(soup):
    """Strip scripts/styles/nav/footer clutter and return readable text."""
    for tag in soup(["script", "style", "noscript", "header", "footer", "nav", "svg", "form"]):
        tag.decompose()

    text = soup.get_text(separator="\n")
    lines = [line.strip() for line in text.splitlines()]
    lines = [line for line in lines if line]  # drop blank lines
    return "\n".join(lines)


def get_internal_links(soup, base_url, base_netloc):
    """Collect all same-domain links found on a page."""
    links = set()
    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        if href.startswith("#") or href.startswith("mailto:") or href.startswith("tel:"):
            continue
        full_url = urljoin(base_url, href).split("#")[0]
        if is_same_domain(full_url, base_netloc):
            links.add(full_url)
    return links


def scrape_website(start_url=BASE_URL, max_pages=MAX_PAGES):
    """Crawl the site breadth-first, starting at the homepage."""
    base_netloc = urlparse(start_url).netloc
    visited = set()
    to_visit = [start_url]
    all_content = []

    while to_visit and len(visited) < max_pages:
        url = to_visit.pop(0)
        if url in visited:
            continue

        try:
            response = requests.get(url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
            response.raise_for_status()
        except requests.RequestException as e:
            print(f"Skipping {url} (error: {e})")
            visited.add(url)
            continue

        soup = BeautifulSoup(response.text, "html.parser")
        page_text = clean_text(soup)
        all_content.append(f"\n===== PAGE: {url} =====\n{page_text}\n")

        visited.add(url)
        print(f"Scraped ({len(visited)}/{max_pages}): {url}")

        for link in get_internal_links(soup, url, base_netloc):
            if link not in visited and link not in to_visit:
                to_visit.append(link)

        time.sleep(DELAY_BETWEEN_REQUESTS)

    return "\n".join(all_content)


def save_content(content, filename=OUTPUT_FILE):
    with open(filename, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"\nSaved {len(content)} characters to '{filename}'")


if __name__ == "__main__":
    print(f"Starting crawl of {BASE_URL} ...\n")
    content = scrape_website()
    if content.strip():
        save_content(content)
    else:
        print("No content was scraped. Check your internet connection or the URL.")
