"""
chatbot.py
----------
Loads the locally-saved website content (produced by scraper.py) and
answers a wide range of dynamically-phrased user questions.

Matching pipeline (each step makes the bot more "dynamic"):
  1. Small-talk / intent detection (greetings, thanks, bye, "who are you")
  2. Synonym expansion (AI -> artificial intelligence, ML -> machine
     learning, sec -> security, etc.) so different wordings still match
  3. Typo correction against the site's own vocabulary
  4. TF-IDF + cosine similarity over paragraph-sized chunks of the
     website content, with each page's URL used as a topic hint - this
     scores *meaningful* keyword overlap instead of requiring an exact
     word match, so rephrased / partial / multi-part questions all work
  5. A confidence threshold - if nothing matches well, the bot admits it
     instead of guessing

Falls back to plain keyword overlap automatically if scikit-learn isn't
installed, so the bot still works either way.

Console usage:
    python chatbot.py
"""

import difflib
import os
import re
import string
from urllib.parse import urlparse

CONTENT_FILE = "website_content.txt"
SIMILARITY_THRESHOLD = 0.12  # below this, the bot says "I don't know"

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

# Domain-specific synonyms/abbreviations so wording differences don't
# break matching (e.g. someone typing "AI" instead of "artificial intelligence").
SYNONYMS = {
    "ai/ml": "artificial intelligence machine learning",
    "ai": "artificial intelligence",
    "ml": "machine learning",
    "sec": "security",
    "cyber": "security cybersecurity",
    "cybersecurity": "security cyber",
    "infosec": "security",
    "automate": "automation",
    "automating": "automation",
    "automated": "automation",
    "biz": "business",
    "co.": "company",
    "svc": "service",
    "svcs": "services",
    "offerings": "services",
    "solutions": "services solutions",
    "pricing": "price cost pricing",
    "contact": "contact reach email phone address",
    "email": "contact reach email phone address",
    "phone": "contact reach email phone address",
    "call": "contact reach email phone address",
    "hire": "careers jobs hiring",
    "job": "careers jobs hiring",
    "cloud computing": "cloud solutions",
}

GREETINGS = {"hi", "hello", "hey", "hola", "greetings", "good morning", "good afternoon", "good evening", "yo"}
THANKS_WORDS = {"thanks", "thank you", "thankyou", "thx", "appreciate it", "appreciated"}
BYE_WORDS = {"bye", "goodbye", "exit", "quit", "see you", "later", "farewell"}
SELF_INTRO_PHRASES = {"who are you", "what are you", "what can you do", "help", "what can you help with", "what do you do"}


def load_content(filename=CONTENT_FILE):
    if not os.path.exists(filename):
        raise FileNotFoundError(
            f"'{filename}' not found. Run scraper.py first to generate it."
        )
    with open(filename, "r", encoding="utf-8") as f:
        return f.read()


def split_into_chunks(text):
    """
    Break the raw scraped text into paragraph-sized chunks, tagging each
    chunk with a lightweight "topic" derived from its page URL (e.g. a
    paragraph from '/security' gets topic "security"). The topic isn't
    shown to the user - it's only used to boost matching relevance.
    """
    lines = text.split("\n")
    chunks = []
    current_topic = ""
    buffer = []

    def flush():
        content = "\n".join(buffer).strip()
        if len(content) > 20:
            chunks.append({"text": content, "topic": current_topic})
        buffer.clear()

    page_pattern = re.compile(r"===== PAGE: (.+) =====")

    for line in lines:
        m = page_pattern.match(line.strip())
        if m:
            flush()
            path = urlparse(m.group(1)).path.strip("/")
            current_topic = path.replace("-", " ").replace("_", " ").replace("/", " ")
            continue
        if line.strip() == "":
            flush()
        else:
            buffer.append(line)
    flush()
    return chunks


def normalize(text):
    return text.lower().translate(str.maketrans("", "", string.punctuation)).strip()


def expand_synonyms(text):
    """Append expansions for any known abbreviation/synonym found in the text."""
    lower = text.lower()
    extras = []
    for key, val in sorted(SYNONYMS.items(), key=lambda kv: -len(kv[0])):
        if key in lower:
            extras.append(val)
    return text + " " + " ".join(extras)


STOPWORDS = set("""
a an the is are was were be been being of on in at to for with and or
what which who whom this that these those do does did have has had
i you he she it we they my your his her its our their as by from
about into can could should would will shall not no if than then
""".split())


def tokenize(text):
    text = normalize(text)
    return [w for w in text.split() if w not in STOPWORDS and len(w) > 2]


class WebsiteChatbot:
    def __init__(self, filename=CONTENT_FILE):
        self.raw_text = load_content(filename)
        self.chunk_data = split_into_chunks(self.raw_text)
        if not self.chunk_data:
            raise ValueError("No usable content found. Check website_content.txt.")

        self.chunks = [c["text"] for c in self.chunk_data]
        # Repeat the topic a few times so it meaningfully nudges the score
        # without overwhelming the actual paragraph content.
        self.search_docs = [
            c["text"] + ((" " + c["topic"]) * 3 if c["topic"] else "")
            for c in self.chunk_data
        ]

        if SKLEARN_AVAILABLE:
            self.vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
            self.doc_vectors = self.vectorizer.fit_transform(self.search_docs)
            self.vocab = set(self.vectorizer.get_feature_names_out())
        else:
            self.chunk_tokens = [set(tokenize(d)) for d in self.search_docs]
            self.vocab = set(w for tokens in self.chunk_tokens for w in tokens)

    # ---------- small talk ----------
    def _intent_reply(self, question):
        q = normalize(question)
        if not q:
            return None
        if q in GREETINGS or any(q.startswith(g) for g in GREETINGS):
            return ("Hello! I'm the Phoenix Digital Technologies assistant. "
                    "Ask me about our company, services, cloud solutions, "
                    "AI/ML, security, or automation offerings.")
        if q in THANKS_WORDS or any(t in q for t in THANKS_WORDS):
            return "You're welcome! Let me know if you have any other questions."
        if q in BYE_WORDS:
            return "Goodbye! Feel free to come back anytime."
        is_short_message = len(q.split()) <= 5
        if is_short_message and any(p in q for p in SELF_INTRO_PHRASES):
            return ("I'm a chatbot trained on the Phoenix Digital Technologies "
                    "website. I can answer questions about the company, its "
                    "services, cloud solutions, AI/ML services, security "
                    "solutions, and automation services.")
        return None

    # ---------- typo tolerance ----------
    def _correct_typos(self, question):
        corrected = []
        for w in question.split():
            w_clean = normalize(w)
            if w_clean and w_clean not in self.vocab and len(w_clean) > 3:
                match = difflib.get_close_matches(w_clean, self.vocab, n=1, cutoff=0.8)
                corrected.append(match[0] if match else w)
            else:
                corrected.append(w)
        return " ".join(corrected)

    # ---------- main answer logic ----------
    def answer(self, question, top_n=3):
        question = (question or "").strip()
        if not question:
            return "Could you please type a question?"

        intent_reply = self._intent_reply(question)
        if intent_reply:
            return intent_reply

        expanded_q = expand_synonyms(question)
        expanded_q = self._correct_typos(expanded_q)

        if SKLEARN_AVAILABLE:
            return self._answer_tfidf(expanded_q, top_n)
        return self._answer_keyword(expanded_q, top_n)

    def _answer_tfidf(self, question, top_n):
        q_vector = self.vectorizer.transform([question])
        similarities = cosine_similarity(q_vector, self.doc_vectors).flatten()
        ranked = sorted(range(len(similarities)), key=lambda i: similarities[i], reverse=True)
        best_idx = ranked[0]

        if similarities[best_idx] < SIMILARITY_THRESHOLD:
            return self._no_match_message()

        selected = [
            i for i in ranked[:top_n]
            if similarities[i] >= max(SIMILARITY_THRESHOLD, similarities[best_idx] * 0.5)
        ]
        if not selected:
            selected = [best_idx]
        return "\n\n".join(self.chunks[i] for i in selected)

    def _answer_keyword(self, question, top_n):
        q_tokens = set(tokenize(question))
        if not q_tokens:
            return self._no_match_message()

        scores = []
        for idx, tokens in enumerate(self.chunk_tokens):
            overlap = q_tokens & tokens
            if overlap:
                scores.append((len(overlap) / len(q_tokens), idx))

        if not scores:
            return self._no_match_message()

        scores.sort(key=lambda x: x[0], reverse=True)
        best_indices = [idx for _, idx in scores[:top_n]]
        return "\n\n".join(self.chunks[i] for i in best_indices)

    @staticmethod
    def _no_match_message():
        return (
            "Sorry, I couldn't find information about that on the "
            "Phoenix Digital Technologies website. Try asking about "
            "the company, services, cloud solutions, AI/ML, security, "
            "or automation."
        )


def run_console_chatbot():
    print("=" * 60)
    print(" Phoenix Digital Technologies - Website Chatbot")
    print("=" * 60)
    print("Ask me anything about the company, services, cloud, AI/ML,")
    print("security, or automation. Type 'exit' to quit.\n")

    try:
        bot = WebsiteChatbot()
    except (FileNotFoundError, ValueError) as e:
        print(str(e))
        return

    while True:
        question = input("You: ").strip()
        response = bot.answer(question)
        print(f"\nBot: {response}\n")
        if normalize(question) in BYE_WORDS:
            break


if __name__ == "__main__":
    run_console_chatbot()
